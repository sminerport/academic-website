from __future__ import annotations
from random import seed
from random import randint
from abc import ABC, abstractmethod, abstractproperty

class DeveloperBuilder(ABC):
    
    @property
    @abstractmethod
    def developer(self) -> None:
        pass
    
    @abstractmethod
    def setType(self) -> None:
        pass
    
    @abstractmethod
    def setCuriosity(self) -> None:
        pass
    
    @abstractmethod
    def setDetail(self) -> None:
        pass
    
    @abstractmethod
    def setReflective(self) -> None:
        pass
    
class SoftwareDeveloperBuilder(DeveloperBuilder):
    
    def __init__(self) -> None:
        self.reset()
        
    def reset(self) -> None:
        self._developer = Developer()
        
    @property
    def developer(self) -> Developer:
        developer = self._developer
        self.reset()
        return developer

    def setType(self, value) -> None:
        self._developer.type = value
        return self
        
    def setCuriosity (self, value) -> None:
        self._developer.curiosity = value
        return self
        
    def setDetail (self, value) -> None:
        self._developer.detail = value
        return self
        
    def setReflective(self, value) -> None:
        self._developer.reflective = value
        return self
    
    def getResult(self) -> Developer:
        return self.developer
        
class Developer():
    "Product"
    
    def __init__(self) -> None:
        self._type = None
        self._curiosity = None
        self._detail = None
        self._reflective = None
    
    @property
    def type (self) -> string:
        return self._type
    
    @property
    def curiosity (self) -> int:
        return self._curiosity
    
    @property
    def detail (self) -> int:
        return self._detail
    
    @property
    def reflective (self) -> int:
        return self._reflective
    
    @type.setter
    def type (self, value) -> None:
        self._type = value
        
    @curiosity.setter
    def curiosity (self, value) -> None:
        self._curiosity = value
        
    @detail.setter
    def detail (self, value) -> None:
        self._detail = value
        
    @reflective.setter
    def reflective (self, value) -> None:
        self._reflective = value
        
    def construction(self) -> None:
        print(f"This is a(n) {self.type}-level developer with a curiosity score of {self.curiosity}"\
        f", an attention to detail score of {self.detail}, and a "\
        f"self-reflective score of {self.reflective}.\n")
        
class Director:

    def __init__(self) -> None:
        self._builder = None
        
    @property
    def builder(self) -> Builder:
        return self._builder
    
    @builder.setter
    def builder(self, builder: Builder) -> None:
        self._builder = builder
    
    def constructRandomDeveloper(self) -> Developer:
        int1 = randint(1,3)
        if int1 == 1:
            developer = self.constructNoviceDeveloper()
            return developer
        elif int1 == 2:
            developer = self.constructIntermediateDeveloper()
            return developer
        elif int1 == 3:
            developer = self.constructExpertDeveloper()
            return developer
        
    def constructNoviceDeveloper(self) -> Developer:
        while(True):
            int1 = randint(1,3)
            int2 = randint(1,3)
            int3 = randint(1,3)
            if (int1 == 1 or int2 == 1 or int3 == 1):
                break;
        return self.builder.setType("novice")\
            .setCuriosity(int1)\
            .setDetail(int2)\
            .setReflective(int3)\
            .getResult()
        
    def constructIntermediateDeveloper(self) -> Developer:
        while(True):
            int1 = randint(2,3)
            int2 = randint(2,3)
            int3 = randint(2,3)
            if (int1 == 2 or int2 == 2 or int3 == 2):
                break;
        return self.builder.setType("intermediate")\
            .setCuriosity(int1)\
            .setDetail(int2)\
            .setReflective(int3)\
            .getResult()
        
    def constructExpertDeveloper(self) -> Developer:
        return self.builder.setType("expert")\
            .setCuriosity(3)\
            .setDetail(3)\
            .setReflective(3)\
            .getResult()
        
def main():
    
    director = Director()
    devBuilder = SoftwareDeveloperBuilder()
    director.builder = devBuilder
    
    for x in range(1, 51):
        developer = director.constructRandomDeveloper()
        print(f"Random Developer #{x}:")
        developer.construction()
        
    print("Novice Developer:")
    developer = director.constructNoviceDeveloper()
    developer.construction()
    
    print("Intermediate Developer:")
    developer = director.constructIntermediateDeveloper()
    developer.construction()
    
    print("Expert Developer:")
    developer = director.constructExpertDeveloper()
    developer.construction()
    
    print("Custom Developer:")
    developer = devBuilder.setType("genius").setCuriosity(4).setDetail(4).setReflective(4).getResult()
    developer.construction()
    
     
if __name__ == "__main__": main()