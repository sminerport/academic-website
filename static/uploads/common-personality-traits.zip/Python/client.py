from director import Director
from software_developer_builder import SoftwareDeveloperBuilder

def main():
    
    director = Director()
    devBuilder = SoftwareDeveloperBuilder()
    director.builder = devBuilder
    
    for x in range(1, 51):
        developer = director.constructRandomDeveloper()
        print(f"Random Developer #{x}:")
        developer.construction()
        
    print("Novice Developer:")
    developer = director.constructNoviceDeveloper()
    developer.construction()
    
    print("Intermediate Developer:")
    developer = director.constructIntermediateDeveloper()
    developer.construction()
    
    print("Expert Developer:")
    developer = director.constructExpertDeveloper()
    developer.construction()
    
    print("Custom Developer:")
    developer = devBuilder.setType("genius").setCuriosity(4).setDetail(4).setReflective(4).getResult()
    developer.construction()
    
     
if __name__ == "__main__": main()