from random import seed
from random import randint

class Dice():
    
    def __init__(self):
        self._result = None
        
    @property
    def result(self):
        return self._result
    
    @result.setter
    def result(self, value):
        self._result = value
        
    def roll(self):
        seed(5)
        self.result = randint(1, 3)