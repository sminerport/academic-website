import sqlite3

class Database():
    
    def createConnection(self):
        try:
            sqliteConnection = sqlite3.connect('SoftwareReq.db')
        except sqlite3.Error as error:
            print("Error while connecting to sqlite", error)
        finally:
            if sqliteConnection:
                sqliteConnection.close()
        
    def createTables(self):
        try:
            sqliteConnection = sqlite3.connect('SoftwareReq.db')
            cursor = sqliteConnection.cursor()
            sqlite_create_table_query = """CREATE TABLE if not exists USERS
                                                            (
                                                                id INTEGER PRIMARY KEY,
                                                                email text,
                                                                pin int
                                                            )"""
            cursor.execute(sqlite_create_table_query)
            sqlite_create_table_query = """CREATE TABLE if not exists SPECIFICATIONS
                                                            (
                                                                userID int NOT NULL,
                                                                vTabs INT,
                                                                hTabs INT,
                                                                menuFile INT,
                                                                menuRepository INT,
                                                                menuCommand INT,
                                                                menuTools INT,
                                                                menuView INT,
                                                                menuNavigate INT,
                                                                menuPlugins INT,
                                                                menuHelp INT,
                                                                menuItemCount INT,
                                                                toolbar INT,
                                                                CONSTRAINT PK_Specifications PRIMARY KEY (userID),
                                                                CONSTRAINT FK_Specifications_Users FOREIGN KEY (userID)
                                                                REFERENCES USERS (id)
                                                                ON DELETE CASCADE
                                                                ON UPDATE CASCADE
                                                            )   
                                                            """;                                                                        
            cursor.execute(sqlite_create_table_query)
            sqliteConnection.commit()
            cursor.close()
        except sqlite3.Error as error:
            print("Error while creating a sqlite table", error)
        finally:
            if (sqliteConnection):
                sqliteConnection.close()
                
    def checkForTies(self):
        try:
            sqliteConnection = sqlite3.connect("SoftwareReq.db")
            sqlite_select_query = """SELECT SUM(CASE WHEN vTabs = 1 THEN 1 ELSE 0 END) as 'vTabsCount',
                                          SUM(CASE WHEN hTabs = 1 THEN 1 ELSE 0 END) as 'hTabsCount',
                                          SUM(CASE WHEN menuItemCount = 4 THEN 1 ELSE 0 END) as 'fourCount',
                                          SUM(CASE WHEN menuItemCount = 6 THEN 1 ELSE 0 END) as 'sixCount',
                                          SUM(CASE WHEN menuItemCount = 8 THEN 1 ELSE 0 END) as 'eightCount',
                                          SUM(CASE WHEN toolbar = 1 THEN 1 ELSE 0 END) as 'barCount',
                                          SUM(CASE WHEN toolbar = 0 THEN 1 ELSE 0 END) as 'noBarCount'
                                          From Specifications"""
            cursor = sqliteConnection.cursor()
            cursor.execute(sqlite_select_query)
            result = cursor.fetchone()
            tabTie = 0
            fourSixTie = 0
            fourEightTie = 0
            sixEightTie = 0
            threeWayTie = 0
            toolbarTie = 0
            if result[0] == result[1]:
                tabTie += 1
            if (result[2] == result[3]) and (result[2] >= 1 or result[3] >= 1):
                fourSixTie += 1
            if result[2] == result[4] and (result[2] >= 1 or result[4] >= 1):
                fourEightTie += 1
            if result[3] == result [4] and (result[3] >= 1 or result[4] >= 1):
                sixEightTie += 1
            if result[2] == result[3] and result[2] == result[4]:
                threeWayTie += 1
            if result[5] == result [6]:
                toolbarTie += 1
            return (tabTie, fourSixTie, fourEightTie, sixEightTie, threeWayTie, toolbarTie)
        except sqlite3.Error as error: 
            print("Error while checking ties", error)
        finally:
            if (sqliteConnection):
                sqliteConnection.close()
                
    def userAvailable(self, email):
        try:
            sqliteConnection = sqlite3.connect("SoftwareReq.db")
            sqlite_select_query = "SELECT count(*) FROM users WHERE email =?"
            cursor = sqliteConnection.cursor()
            cursor.execute(sqlite_select_query, (email.lower(),))
            data=cursor.fetchone()[0]
            if data==0:
                return True
            else:
                return False
            cursor.close()
        except sqlite3.Error as error:
            print("Error while connecting to sqlite", error)
        finally:
            if (sqliteConnection):
                sqliteConnection.close()
                
    def insertUserAndPin(self, email, pin):
        try:
            sqliteConnection = sqlite3.connect("SoftwareReq.db")
            sqlite_insert_statement = "INSERT INTO users (email, pin) VALUES (?, ?)"
            cursor = sqliteConnection.cursor()
            cursor.execute(sqlite_insert_statement, (email.lower(), pin))
            sqliteConnection.commit()
            cursor.close()
        except sqlite3.Error as error:
            print("Error while inserting into user table", error)
        finally:
            if (sqliteConnection):
                sqliteConnection.close()
                
    def updateTies(self, email, software):
        try:
            sqliteConnection = sqlite3.connect("SoftwareReq.db")
            sqlite_select_statement = "SELECT id FROM users WHERE email =?"
            cursor = sqliteConnection.cursor()
            cursor.execute(sqlite_select_statement, (email.lower(),))
            result = cursor.fetchone()
            result = result[0]
            sqlite_insert_statement = """INSERT or REPLACE into conflicts (userid, vtabs, htabs, menuFile, menuRepository, menuCommand,
                                                        menuTools, menuView, menuNavigate, menuPlugins, menuHelp, menuItemCount, toolbar) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"""
            cursor.execute(sqlite_insert_statement, (result, software.getVTabs(), software.getHTabs(),
                                                     software.getMenuFile(), software.getMenuRepo(), software.getMenuComm(),
                                                     software.getMenuTools(), software.getMenuView(), software.getMenuNav(),
                                                     software.getMenuPlug(), software.getMenuHelp(), software.getMenuItemCount(), software.getToolbar()))
            sqliteConnection.commit()
            cursor.close()
        except sqlite3.Error as error:
                print("Error while inserting into specifications table", error)
        finally:
            if (sqliteConnection):
                sqliteConnection.close()
                
    def insertSpecification(self, email, software):
        try:
            sqliteConnection = sqlite3.connect("SoftwareReq.db")
            sqlite_select_statement = "SELECT id FROM users WHERE email =?"
            cursor = sqliteConnection.cursor()
            cursor.execute(sqlite_select_statement, (email.lower(),))
            result = cursor.fetchone()
            result = result[0]
            sqlite_insert_statement = """INSERT or REPLACE into specifications (userid, vtabs, htabs, menuFile, menuRepository, menuCommand,
                                                        menuTools, menuView, menuNavigate, menuPlugins, menuHelp, menuItemCount, toolbar) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"""
            cursor.execute(sqlite_insert_statement, (result, software.getVTabs(), software.getHTabs(),
                                                     software.getMenuFile(), software.getMenuRepo(), software.getMenuComm(),
                                                     software.getMenuTools(), software.getMenuView(), software.getMenuNav(),
                                                     software.getMenuPlug(), software.getMenuHelp(), software.getMenuItemCount(), software.getToolbar()))
            sqliteConnection.commit()
            cursor.close()
        except sqlite3.Error as error:
                print("Error while inserting into specifications table", error)
        finally:
            if (sqliteConnection):
                sqliteConnection.close()
                
    def validPin(self, email, inputPin):
        try:
            sqliteConnection = sqlite3.connect("SoftwareReq.db")
            sqlite_select_query = "SELECT pin FROM users WHERE email=?"
            cursor = sqliteConnection.cursor()
            result = cursor.execute(sqlite_select_query, (email.lower(), ))
            try:
                dbPin = next(result)
                if dbPin[0] == inputPin:
                    cursor.close()
                    return True
                else:
                    cursor.close()
                    return False
            except StopIteration as e:
                cursor.close()
                return False
        except sqlite3.Error as error:
            print("Error while searching the database", error)
        finally:
            if (sqliteConnection):
                sqliteConnection.close()
