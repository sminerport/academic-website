from __future__ import annotations

class Developer():
    "Product"
    
    def __init__(self) -> None:
        self._type = None
        self._curiosity = None
        self._detail = None
        self._reflective = None
    
    @property
    def type (self) -> string:
        return self._type
    
    @property
    def curiosity (self) -> int:
        return self._curiosity
    
    @property
    def detail (self) -> int:
        return self._detail
    
    @property
    def reflective (self) -> int:
        return self._reflective
    
    @type.setter
    def type (self, value) -> None:
        self._type = value
        
    @curiosity.setter
    def curiosity (self, value) -> None:
        self._curiosity = value
        
    @detail.setter
    def detail (self, value) -> None:
        self._detail = value
        
    @reflective.setter
    def reflective (self, value) -> None:
        self._reflective = value
        
    def construction(self) -> None:
        print(f"This is a(n) {self.type}-level developer with a curiosity score of {self.curiosity}"\
        f", an attention to detail score of {self.detail}, and a "\
        f"self-reflective score of {self.reflective}.\n")