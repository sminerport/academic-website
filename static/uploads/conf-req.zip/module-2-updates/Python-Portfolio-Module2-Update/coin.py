from random import seed
from random import randint

class Coin():
    
    def __init__(self):
        self._result = None
        
    @property
    def result(self):
        return self._result
    
    @result.setter
    def result(self, value):
        self._result = value
    
    def flip(self):
        if (randint(0, 1) == 0):
            self.result = 'tails'
        if (randint(0, 1) == 1):
            self.result = 'heads'
        