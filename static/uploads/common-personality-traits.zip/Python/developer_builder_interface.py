from __future__ import annotations
from abc import ABC, abstractmethod, abstractproperty

class DeveloperBuilder(ABC):
    
    @property
    @abstractmethod
    def developer(self) -> None:
        pass
    
    @abstractmethod
    def setType(self) -> None:
        pass
    
    @abstractmethod
    def setCuriosity(self) -> None:
        pass
    
    @abstractmethod
    def setDetail(self) -> None:
        pass
    
    @abstractmethod
    def setReflective(self) -> None:
        pass
    