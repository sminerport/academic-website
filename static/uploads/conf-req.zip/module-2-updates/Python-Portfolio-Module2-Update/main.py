from database import Database
from user import User

def main():
    db = Database()
    db.createConnection()
    db.createTables()
    user = User()
    user.getLoginOption()
    
if __name__ == "__main__": main()