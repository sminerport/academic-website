from app import db, login
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from sqlalchemy.sql import expression
import random

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(100))
    last_name = db.Column(db.String(100))
    email = db.Column(db.String(120), index=True, unique=True)
    username = db.Column(db.String(64), index=True, unique=True)
    pin_hash = db.Column(db.String(128))
    attempts = db.Column(db.Integer, default=0)
    locked = db.Column(db.Boolean, default=False, nullable=False)
    accounts = db.relationship('Account', backref='owner', lazy='dynamic',
        cascade="all, delete")

    def set_pin(self, pin):
        self.pin_hash = generate_password_hash(pin)

    def check_pin(self, pin):
        return check_password_hash(self.pin_hash, pin)

    def __repr__(self):
        return  f"{'<User ID':>10}: {self.id}\n{'First Name':>10}: {self.first_name}\n"\
                f"{'Last Name':>10}: {self.last_name}\n{'Username':>10}: {self.username}\n"\
                f"{'Pin Hash:':>10}: {self.pin_hash}\n"\
                f"{'Email':>10}: {self.email}\n{'Attempts':>10}: {self.attempts}\n"\
                f"{'Locked':>10}: {self.locked}>\n"

class Account(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    balance = db.Column(db.Float)
    type = db.Column(db.String(50))
    status = db.Column(db.String(50))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))

    def __repr__(self):
        return  f"{'<Account ID':>15}: {self.id}\n{'Balance':>15}: {self.balance}\n"\
                f"{'Type':>15}: {self.type}\n{'Status':>15}: {self.status}\n"\
                f"{'User ID':>15}: {self.user_id}>\n"

@login.user_loader
def load_user(id):
    return User.query.get(int(id))
