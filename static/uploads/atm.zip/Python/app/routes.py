from app import app, db
from flask import render_template, url_for, redirect, request, flash, g
from flask_login import current_user, login_user, logout_user, login_required
from app.models import User, Account
from app.forms import LoginForm, RegistrationForm, WithdrawalForm1, WithdrawalForm2
from werkzeug.urls import url_parse

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user is None:
            flash('Invalid username or password')
            return redirect(url_for('login'))
        if user.locked:
            flash('Too many failed attempts.  Please contact customer service.')
            return redirect(url_for('login'))
        if (user.attempts >= 2):
            flash('Too many failed attempts.  Please contact customer service.')
            user.attempts += 1
            user.locked = True
            db.session.commit()
            return redirect(url_for('login'))
        # if the user enters the incorrect pin
        if not user.check_pin(form.pin.data):
            user.attempts += 1
            db.session.commit()
            flash('Invalid username or password')
            return redirect(url_for('login'))
        # log user in
        login_user(user, remember=form.remember_me.data)
        # get url query arguments
        next_page = request.args.get('next')
        # if url query args are none (requested page)
        # or network locality attempts to redirect externally (hack)
        # redirect to accounts page of user
        if not next_page or url_parse(next_page).netloc != '':
            next_page = url_for('accounts', username=current_user.username)
        user.attempts = 0
        db.session.commit()
        return redirect(next_page)
    return render_template('login.html', title='Sign In', form=form)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = RegistrationForm()
    if form.validate_on_submit():
        user = User(first_name=form.firstName.data, \
        last_name=form.lastName.data, username=form.username.data, \
        email=form.email.data, locked=False)
        user.set_pin(form.pin.data)
        Account(type="Checking Account", status="Open", balance=100.00, owner=user)
        db.session.add(user)
        db.session.commit()
        flash('Congratulations, you are now a registered user!')
        return redirect(url_for('login'))
    return render_template('register2.html', title='Register', form=form)

@app.route('/accounts/<username>', methods=['GET', 'POST'])
@login_required
def accounts(username):
    if request.method == 'POST':
        print("hello")
        acctID = request.form.get('acctID')
        print(acctID)
        return redirect(url_for('withdrawal', username=current_user.username, acctID=acctID))

    user = User.query.filter_by(username=username).first_or_404()
    return render_template('accounts.html', user=user, accounts=user.accounts)

@app.route('/accounts/<username>/withdrawal/<int:acctID>', methods=['GET', 'POST'])
@login_required
def withdrawal(username, acctID):
    form1 = WithdrawalForm1()
    form2 = WithdrawalForm2()
    g.acctID = acctID
    account = Account.query.filter_by(id=acctID).first()
    user = User.query.filter_by(username=username).first_or_404()
    if form1.validate_on_submit():
        if (form1.twenty.data):
            account.balance -= 20
        elif (form1.forty.data):
            account.balance -= 40
        elif (form1.sixty.data):
            account.balance -= 60
        elif (form1.eighty.data):
            account.balance -= 80
        if account.balance == 0:
            account.status = 'Closed'
        db.session.commit()
        return redirect(url_for('accounts', username=current_user.username))

    return render_template('withdrawal.html', user=user, account=account, form1=form1, form2=form2)

@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/')
@app.route('/index')
def index():
    return redirect(url_for('register'))
