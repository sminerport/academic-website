from plantuml import PlantUML
from os.path import abspath
from PIL import Image
import os
import re

class File():
    
    def __init__(self):
        self._directory = None
        self._parentDirectory = "./"
        self._path = None
        self._plantUMLText = None
        
    def getDirectory(self):
        return self._directory
    
    def getParentDirectory(self):
        return self._parentDirectory
    
    def getPath(self):
        return self._path
    
    def getPlantUMLText(self):
        return self._plantUMLText
    
    def setDirectory(self, x):
        self._directory = x
        
    def setPath(self, x):
        self._path = x
        
    def setPlantUMLText(self, x):
        self._plantUMLText = x
        
    def createDirectory(self, email):
        self.setDirectory(email)
        self.setPath(os.path.join(self.getParentDirectory(), self.getDirectory()))
        if not os.path.isdir(self.getPath()):
            os.mkdir(self.getPath())
            
    def createPlantUMLSource(self, software):
        if software.getHTabs() and software.getMenuItemCount() == 4 and software.getToolbar():
            self.setPlantUMLText("""@startsalt
scale 5
{+
{* File | Repository | Command | Help }
{!                        
{/ Commit | Diff | <b>File Tree</b> | Console} { Toolbar:    <&home> <&folder> <&plus> <&chevron-left> <&chevron-right> <&clipboard> <&terminal> <&fork> <&transfer> <&loop-circular> <&cog> <&question-mark>}
{T 
+My Computer
++ Local Disk (C:)
+++ Users
++++ YourName
++++ Documents
++++ Desktop
++++ OneDrive
+++++ Documents
++++++ Development Files} |
{ Search: | "testFile.py" | *
Branches: | ^Master^ | *
Command:  | (X) init | () push 
|.| () pull | () merge
|.| () fetch | *
Include: | [X] readme.md | [X] .gitignore
|.|[Cancel]|[Ok]} 
}
} 
@endsalt""")
            with open(abspath(self.getPath() + '/plant-uml.txt'), 'w') as writer:
                writer.write(self.getPlantUMLText())
                
        elif software.getHTabs() and software.getMenuItemCount() == 4 and not software.getToolbar():
            self.setPlantUMLText("""@startsalt
scale 5
{+
{* File | Repository | Command | Help }
{!                        
{/ Commit | Diff | <b>File Tree</b> | Console}
{T 
+My Computer
++ Local Disk (C:)
+++ Users
++++ YourName
++++ Documents
++++ Desktop
++++ OneDrive
+++++ Documents
++++++ Development Files} |
{ Search: | "testFile.py" | *
Branches: | ^Master^ | *
Command:  | (X) init | () push 
|.| () pull | () merge
|.| () fetch | *
Include: | [X] readme.md | [X] .gitignore
|.|[Cancel]|[Ok]} 
}
} 
@endsalt""")
            with open(abspath(self.getPath() + '/plant-uml.txt'), 'w') as writer:
                writer.write(self.getPlantUMLText())    
            
        elif  software.getHTabs() and software.getMenuItemCount() == 6 and software.getToolbar():
            self.setPlantUMLText("""@startsalt
scale 5
{+
{* File | Repository | Command | Plugins | Tools | Help }
{!                        
{/ Commit | Diff | <b>File Tree</b> | Console} { Toolbar:    <&home> <&folder> <&plus> <&chevron-left> <&chevron-right> <&clipboard> <&terminal> <&fork> <&transfer> <&loop-circular> <&cog> <&question-mark>}
{T 
+My Computer
++ Local Disk (C:)
+++ Users
++++ YourName
++++ Documents
++++ Desktop
++++ OneDrive
+++++ Documents
++++++ Development Files} |
{ Search: | "testFile.py" | *
Branches: | ^Master^ | *
Command:  | (X) init | () push 
|.| () pull | () merge
|.| () fetch | *
Include: | [X] readme.md | [X] .gitignore
|.|[Cancel]|[Ok]} 
}
} 
@endsalt""")
            with open(abspath(self.getPath() + '/plant-uml.txt'), 'w') as writer:
                writer.write(self.getPlantUMLText())
                
        elif software.getHTabs() and software.getMenuItemCount() == 6 and not software.getToolbar():
            self.setPlantUMLText("""@startsalt
scale 5
{+
{* File | Repository | Command | Plugins | Tools | Help }
{!                        
{/ Commit | Diff | <b>File Tree</b> | Console}
{T 
+My Computer
++ Local Disk (C:)
+++ Users
++++ YourName
++++ Documents
++++ Desktop
++++ OneDrive
+++++ Documents
++++++ Development Files} |
{ Search: | "testFile.py" | *
Branches: | ^Master^ | *
Command:  | (X) init | () push 
|.| () pull | () merge
|.| () fetch | *
Include: | [X] readme.md | [X] .gitignore
|.|[Cancel]|[Ok]} 
}
} 
@endsalt""")
            with open(abspath(self.getPath() + '/plant-uml.txt'), 'w') as writer:
                writer.write(self.getPlantUMLText())
                
        elif  software.getHTabs() and software.getMenuItemCount() == 8 and software.getToolbar():
            self.setPlantUMLText("""@startsalt
scale 5
{+
{* File | Repository | Command | Plugins | Tools | View | Navigate | Help }
{!                        
{/ Commit | Diff | <b>File Tree</b> | Console} { Toolbar:    <&home> <&folder> <&plus> <&chevron-left> <&chevron-right> <&clipboard> <&terminal> <&fork> <&transfer> <&loop-circular> <&cog> <&question-mark>}
{T 
+My Computer
++ Local Disk (C:)
+++ Users
++++ YourName
++++ Documents
++++ Desktop
++++ OneDrive
+++++ Documents
++++++ Development Files} |
{ Search: | "testFile.py" | *
Branches: | ^Master^ | *
Command:  | (X) init | () push 
|.| () pull | () merge
|.| () fetch | *
Include: | [X] readme.md | [X] .gitignore
|.|[Cancel]|[Ok]} 
}
} 
@endsalt""")
            with open(abspath(self.getPath() + '/plant-uml.txt'), 'w') as writer:
                writer.write(self.getPlantUMLText())
                
        elif  software.getHTabs() and software.getMenuItemCount() == 8 and not software.getToolbar():
            self.setPlantUMLText("""@startsalt
scale 5
{+
{* File | Repository | Command | Plugins | Tools | View | Navigate | Help }
{!                        
{/ Commit | Diff | <b>File Tree</b> | Console} 
{T 
+My Computer
++ Local Disk (C:)
+++ Users
++++ YourName
++++ Documents
++++ Desktop
++++ OneDrive
+++++ Documents
++++++ Development Files} |
{ Search: | "testFile.py" | *
Branches: | ^Master^ | *
Command:  | (X) init | () push 
|.| () pull | () merge
|.| () fetch | *
Include: | [X] readme.md | [X] .gitignore
|.|[Cancel]|[Ok]} 
}
} 
@endsalt""")
            with open(abspath(self.getPath() + '/plant-uml.txt'), 'w') as writer:
                writer.write(self.getPlantUMLText())                

        elif software.getVTabs() and software.getMenuItemCount() == 4 and software.getToolbar():
            self.setPlantUMLText("""@startsalt
scale 5
{+
{* File | Repository | Command | Help | <&home> <&folder> <&plus> <&chevron-left> <&chevron-right> <&clipboard> <&terminal> <&fork> <&transfer> <&loop-circular> <&cog> <&question-mark>}
{                         
{/
Commit
Diff 
<b>File Tree</b>
Console
} | 
{T 
+My Computer
++ Local Disk (C:)
+++ Users
++++ YourName
++++ Documents
++++ Desktop
++++ OneDrive
+++++ Documents
++++++ Development Files} |
{ Search: | "testFile.py" | *
Branches: | ^Master^ | *
Command:  | (X) init | () push 
|.| () pull | () merge
|.| () fetch | *
Include: | [X] readme.md | [X] .gitignore
|.|[Cancel]|[Ok]} 
}
} 
@endsalt""")
            with open(abspath(self.getPath() + '/plant-uml.txt'), 'w') as writer:
                writer.write(self.getPlantUMLText())
                
        elif software.getVTabs() and software.getMenuItemCount() == 4 and not software.getToolbar():
            self.setPlantUMLText("""@startsalt
scale 5
{+
{* File | Repository | Command | Help }
{                         
{/
Commit
Diff 
<b>File Tree</b>
Console
} | 
{T 
+My Computer
++ Local Disk (C:)
+++ Users
++++ YourName
++++ Documents
++++ Desktop
++++ OneDrive
+++++ Documents
++++++ Development Files} |
{ Search: | "testFile.py" | *
Branches: | ^Master^ | *
Command:  | (X) init | () push 
|.| () pull | () merge
|.| () fetch | *
Include: | [X] readme.md | [X] .gitignore
|.|[Cancel]|[Ok]} 
}
} 
@endsalt""")
            with open(abspath(self.getPath() + '/plant-uml.txt'), 'w') as writer:
                writer.write(self.getPlantUMLText())
                
        elif software.getVTabs() and software.getMenuItemCount() == 6 and software.getToolbar():
            self.setPlantUMLText("""@startsalt
scale 5
{+
{* File | Repository | Command | Plugins | Tools | Help | <&home> <&folder> <&plus> <&chevron-left> <&chevron-right> <&clipboard> <&terminal> <&fork> <&transfer> <&loop-circular> <&cog> <&question-mark>}
{                         
{/
Commit
Diff 
<b>File Tree</b>
Console
} | 
{T 
+My Computer
++ Local Disk (C:)
+++ Users
++++ YourName
++++ Documents
++++ Desktop
++++ OneDrive
+++++ Documents
++++++ Development Files} |
{ Search: | "testFile.py" | *
Branches: | ^Master^ | *
Command:  | (X) init | () push 
|.| () pull | () merge
|.| () fetch | *
Include: | [X] readme.md | [X] .gitignore
|.|[Cancel]|[Ok]} 
}
} 
@endsalt""")

            with open(abspath(self.getPath() + '/plant-uml.txt'), 'w') as writer:
                writer.write(self.getPlantUMLText())
                
        elif software.getVTabs() and software.getMenuItemCount() == 6 and not software.getToolbar():
            self.setPlantUMLText("""@startsalt
scale 5
{+
{* File | Repository | Command | Plugins | Tools | Help }
{                         
{/
Commit
Diff 
<b>File Tree</b>
Console
} | 
{T 
+My Computer
++ Local Disk (C:)
+++ Users
++++ YourName
++++ Documents
++++ Desktop
++++ OneDrive
+++++ Documents
++++++ Development Files} |
{ Search: | "testFile.py" | *
Branches: | ^Master^ | *
Command:  | (X) init | () push 
|.| () pull | () merge
|.| () fetch | *
Include: | [X] readme.md | [X] .gitignore
|.|[Cancel]|[Ok]} 
}
} 
@endsalt""")

            with open(abspath(self.getPath() + '/plant-uml.txt'), 'w') as writer:
                writer.write(self.getPlantUMLText())

        if software.getVTabs() and software.getMenuItemCount() == 8 and software.getToolbar():
            self.setPlantUMLText("""@startsalt
scale 5
{+
{* File | Repository | Command | Plugins | Tools | View | Navigate | Help | }
{ 
{/
Commit
Diff 
<b>File Tree</b>
Console
} | 
{T
+My Computer
++ Local Disk (C:)
+++ Users
++++ YourName
++++ Documents
++++ Desktop
++++ OneDrive
+++++ Documents
++++++ Development Files} |
{ Search: | "testFile.py" | <&home> <&folder> <&plus> <&chevron-left> <&chevron-right> <&clipboard> 
Branches: | ^Master^  | <&terminal> <&fork> <&transfer><&loop-circular> <&cog> <&question-mark> 
Command:  | (X) init | () push 
|.| () pull | () merge
|.| () fetch | *
Include: | [X] readme.md | [X] .gitignore
|.|[Cancel] |[Ok]} 
}
} 
@endsalt""")
            with open(abspath(self.getPath() + '/plant-uml.txt'), 'w') as writer:
                writer.write(self.getPlantUMLText())
            
        elif software.getVTabs() and software.getMenuItemCount() == 8 and not software.getToolbar():
            self.setPlantUMLText("""@startsalt
scale 5
{+
{* File | Repository | Command | Plugins | Tools | View | Navigate | Help | }
{ 
{/
Commit
Diff 
<b>File Tree</b>
Console
} | 
{T
+My Computer
++ Local Disk (C:)
+++ Users
++++ YourName
++++ Documents
++++ Desktop
++++ OneDrive
+++++ Documents
++++++ Development Files} |
{ Search: | "testFile.py" | *
Branches: | ^Master^  | *
Command:  | (X) init | () push 
|.| () pull | () merge
|.| () fetch | *
Include: | [X] readme.md | [X] .gitignore
|.|[Cancel] |[Ok]} 
}
} 
@endsalt""")
            with open(abspath(self.getPath() + '/plant-uml.txt'), 'w') as writer:
                writer.write(self.getPlantUMLText())
                
    def createImage(self):                  

        # create a server object to call for your computations
        server = PlantUML(url='http://www.plantuml.com/plantuml/img/',
                                  basic_auth={},
                                  form_auth={}, http_opts={}, request_opts={})
    
        # Send and compile your diagram files to/with the PlantUML server
        server.processes_file(abspath(self.getPath() + '/plant-uml.txt'))
        
    def showImage(self):
        im = Image.open(abspath(self.getPath() + '/plant-uml.png'))
        im.show()
        