from __future__ import annotations
from developer_builder_interface import DeveloperBuilder
from developer import Developer

class SoftwareDeveloperBuilder(DeveloperBuilder):
    
    def __init__(self) -> None:
        self.reset()
        
    def reset(self) -> None:
        self._developer = Developer()
        
    @property
    def developer(self) -> Developer:
        developer = self._developer
        self.reset()
        return developer

    def setType(self, value) -> None:
        self._developer.type = value
        return self
        
    def setCuriosity (self, value) -> None:
        self._developer.curiosity = value
        return self
        
    def setDetail (self, value) -> None:
        self._developer.detail = value
        return self
        
    def setReflective(self, value) -> None:
        self._developer.reflective = value
        return self
    
    def getResult(self) -> Developer:
        return self.developer