class Menu():

    def __init__ (self):
        self._loginMenu = """
Welcome to the Software Specifications Application.
Please choose from the choices below.
    
*************************************
*                                   *
*   [1] Register New User           *
*   [2] Log in                      *
*   [0] Exit the program            *
*                                   *
*************************************
"""
        self._menuRequirementMenu = """
**********************************************
*   Welcome to the Specification Questions   *
**********************************************

1. How many menu options should the program contain?
    
****************************************************************************************
*                                                                                      *
*   [1] 4 (File, Repository, Command, Help)                                            *
*   [2] 6 (File, Repository, Command, Tools, Plugins, Help)                            *
*   [3] 8 (File, Repository, Command, Tools, View, Navigate, Plugins, Help)            *
*   [0] Exit the Program                                                               *
*                                                                                      *
****************************************************************************************
"""
        self._tabRequirementMenu ="""
2. Do you want the program to contain horizontal or vertical tabs?
    
*************************************
*                                   *
*   [1] Vertical                    *
*   [2] Horizontal                  *
*   [0] Exit the program            *
*                                   *
*************************************
"""
        self._toolbarRequirementMenu = """
3. Should the application contain a toolbar?
    
*************************************
*                                   * 
*   [1] Yes                         *
*   [2] No                          *
*   [0] Exit the Program            *
*                                   *
*************************************
"""

        self._creatingImageMessage = """
****************************************************
*   Creating and opening specifications image...   *      
****************************************************

Returning to main menu..."""

    def getLoginMenu(self):
        return self._loginMenu
    
    def getMenuRequirementMenu(self):
        return self._menuRequirementMenu
    
    def getTabRequirementMenu(self):
        return self._tabRequirementMenu
    
    def getToolbarRequirementMenu(self):
        return self._toolbarRequirementMenu
    
    def getCreatingImageMessage(self):
        return self._creatingImageMessage