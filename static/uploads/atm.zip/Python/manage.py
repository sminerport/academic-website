from flask import Flask
from config import Config
from flask_sqlalchemy import SQLAlchemy
from flask_script import Manager
from flask_script import Command

app = Flask(__name__)
app.config.from_object(Config)
db = SQLAlchemy(app)
# configure your BankingApp

manager = Manager(app)

from app.models import User, Account
@manager.command
def seed():

    u1 = User(
        first_name="Test",
        last_name="User1",
        email="test1@example.com",
        username="TestUser1"
        )
    u1.set_pin('1234')
    u2 = User(
        first_name="Test",
        last_name="User2",
        email="test2@example.com",
        username="TestUser2"
        )
    u2.set_pin('123456')
    u3 = User(
        first_name="Test",
        last_name="User3",
        email="test3@example.com",
        username="TestUser3"
        )
    u3.set_pin('4321')
    u4 = User(
            first_name="Test",
            last_name="User4",
            email="test4@example.com",
            username="TestUser4"
            )
    u4.set_pin('5678')
    u5 = User(
            first_name="Test",
            last_name="User4",
            email="test5@example.com",
            username="TestUser5"
            )
    u5.set_pin('01234')
    accounts = [
        Account(balance = 200.00, type="Checking Account", status="Open",owner=u1),
        Account(balance = 1000.00, type="Savings Account", status="Open", owner=u1),
        Account(balance = 50.00, type="Checking Account", status="Open", owner=u2),
        Account(balance = 2000.00, type="Savings Account", status="Open", owner=u2),
        Account(balance = 75.00, type="Checking Account", status="Open", owner=u3),
        Account(balance = 3000.00, type="Savings Account", status="Open", owner=u4),
        Account(balance = 1000.00, type="Checking Account", status="Open", owner=u4),
        Account(balance = 4500.00, type="Savings Account", status="Open", owner=u5),
        Account(balance = 5000.00, type="Checking Account", status="Open", owner=u5),
        Account(balance = 6000.00, type="Money Market", status="Open", owner=u5)
    ]
    db.session.add_all([u1, u2, u3, u4, u5])
    db.session.commit()

if __name__ == "__main__":
    # prepares the Manager instance to
    # receive input from the command line
    manager.run()
