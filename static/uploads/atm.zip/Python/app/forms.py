from flask import g
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField
from wtforms.validators import ValidationError, DataRequired, Email, EqualTo
from app.models import User, Account

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    pin = PasswordField('Pin', validators=[DataRequired()])
    remember_me = BooleanField('Remember Me')
    submit = SubmitField('Sign In')

class RegistrationForm(FlaskForm):
    firstName = StringField('First Name', validators=[DataRequired()])
    lastName = StringField('Last Name', validators=[DataRequired()])
    username = StringField('Username', validators=[DataRequired()])
    email = StringField('Email', validators=[DataRequired(), Email()])
    pin = PasswordField('Pin', validators=[DataRequired()])
    pin2 = PasswordField('Repeat Pin', validators=[DataRequired(), EqualTo('pin')])
    submit = SubmitField('Register Now')

    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user is not None:
            raise ValidationError('Please use a different username.')

    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user is not None:
            raise ValidationError('Please use a different email address.')

    def validate_pin(self, pin):
        if not pin.data.isdecimal():
            raise ValidationError('Pin can only contain digits.')
        if len(pin.data) < 4 or len(pin.data) > 8:
            raise ValidationError('Pin must be between 4 and 8 characters long')

    def validate_pin2(self, pin2):
        if not pin2.data.isdecimal():
            raise ValidationError('Pin can only contain digits.')

class WithdrawalForm1(FlaskForm):
    twenty = SubmitField("$20")
    forty = SubmitField("$40")
    sixty = SubmitField("$60")
    eighty = SubmitField("$80")

    def validate_twenty(self, twenty):
        acctID = g.acctID
        a = Account.query.get(acctID)
        if (twenty.data):
            if 20 > a.balance:
                raise ValidationError('Not enough money in account')

    def validate_forty(self, forty):
        acctID = g.acctID
        a = Account.query.get(acctID)
        if (forty.data):
            if 40 > a.balance:
                raise ValidationError('Not enough money in account')

    def validate_sixty(self, sixty):
        acctID = g.acctID
        a = Account.query.get(acctID)
        if (sixty.data):
            if 60 > a.balance:
                raise ValidationError('Not enough money in account')

    def validate_eighty(self, eighty):
        acctID = g.acctID
        a = Account.query.get(acctID)
        if (eighty.data):
            if 80 > a.balance:
                raise ValidationError('Not enough money in account')

class WithdrawalForm2(FlaskForm):
    other = StringField('Other', validators=[DataRequired()])
    submit = SubmitField('Submit')
