class Software():
    def __init__ (self):
        self._vtabs = 0
        self._htabs = 0
        self._menuFile = 0
        self._menuRepo = 0
        self._menuComm = 0
        self._menuTools = 0
        self._menuView = 0
        self._menuNav = 0
        self._menuPlug = 0
        self._menuHelp = 0
        self._menuItemCount = 0
        self._toolbar = 0
        
    def setHTabs (self, x):
        self._htabs = x
        
    def setVTabs (self, x):
        self._vtabs = x
        
    def setMenuFile (self, x):
        self._menuFile = x
        
    def setMenuRepo (self, x):
        self._menuRepo = x
        
    def setMenuComm (self, x):
        self._menuComm = x
        
    def setMenuTools (self, x):
        self._menuTools = x
        
    def setMenuView (self, x):
        self._menuView = x
        
    def setMenuNav (self, x):
        self._menuNav = x
        
    def setMenuPlug (self, x):
        self._menuPlug = x
        
    def setMenuHelp (self, x):
        self._menuHelp = x
        
    def setMenuItemCount (self, x):
        self._menuItemCount = x
        
    def setToolbar (self, x):
        self._toolbar = x
      
    def getHTabs (self):
        return self._htabs
        
    def getVTabs (self):
        return self._vtabs
        
    def getMenuFile (self):
        return self._menuFile
        
    def getMenuRepo (self):
        return self._menuRepo
        
    def getMenuComm (self):
        return self._menuComm
        
    def getMenuTools (self):
        return self._menuTools
        
    def getMenuView (self):
        return self._menuView
        
    def getMenuNav (self):
        return self._menuNav
        
    def getMenuPlug (self):
       return self._menuPlug
        
    def getMenuHelp (self):
        return self._menuHelp
    
    def getMenuItemCount(self):
        return self._menuItemCount
    
    def getToolbar(self):
        return self._toolbar