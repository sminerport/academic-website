from __future__ import annotations
from random import seed
from random import randint

class Director:

    def __init__(self) -> None:
        self._builder = None
        
    @property
    def builder(self) -> Builder:
        return self._builder
    
    @builder.setter
    def builder(self, builder: Builder) -> None:
        self._builder = builder
    
    def constructRandomDeveloper(self) -> Developer:
        int1 = randint(1,3)
        if int1 == 1:
            developer = self.constructNoviceDeveloper()
            return developer
        elif int1 == 2:
            developer = self.constructIntermediateDeveloper()
            return developer
        elif int1 == 3:
            developer = self.constructExpertDeveloper()
            return developer
        
    def constructNoviceDeveloper(self) -> Developer:
        while(True):
            int1 = randint(1,3)
            int2 = randint(1,3)
            int3 = randint(1,3)
            if (int1 == 1 or int2 == 1 or int3 == 1):
                break;
        return self.builder.setType("novice")\
            .setCuriosity(int1)\
            .setDetail(int2)\
            .setReflective(int3)\
            .getResult()
        
    def constructIntermediateDeveloper(self) -> Developer:
        while(True):
            int1 = randint(2,3)
            int2 = randint(2,3)
            int3 = randint(2,3)
            if (int1 == 2 or int2 == 2 or int3 == 2):
                break;
        return self.builder.setType("intermediate")\
            .setCuriosity(int1)\
            .setDetail(int2)\
            .setReflective(int3)\
            .getResult()
        
    def constructExpertDeveloper(self) -> Developer:
        return self.builder.setType("expert")\
            .setCuriosity(3)\
            .setDetail(3)\
            .setReflective(3)\
            .getResult()