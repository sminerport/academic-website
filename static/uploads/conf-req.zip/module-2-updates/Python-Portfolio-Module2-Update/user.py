from menu import Menu
from database import Database
from file import File
from software import Software
from random import randint
from coin import Coin
from dice import Dice
import re

class User():
    
    def __init__(self):
        self._email = None
        self._pin = None
        self._pinString = None
        self._option = None
        self._menu = Menu()
        self._software = Software()
        self._file = File()
        
    def getEmail(self):
        return self._email
    
    def getPin(self):
        return self._pin
    
    def getPinString(self):
        return self._pinString
    
    def getOption(self):
        return self._option
    
    def getMenu(self):
        return self._menu
    
    def getSoftware(self):
        return self._software
    
    def getFile(self):
        return self._file
    
    def setEmail(self, x):
        self._email = x
        
    def setPin(self, x):
        self._pin = x
        
    def setPinString(self, x):
        self._pinString = x
        
    def setOption(self, x):
        self._option = x
        
    def setFile(self, x):
        self._file = x
        
    def getLoginOption(self):
        while self.getOption() != 0:
            #try to convert user input to a number
            try:
                print(self.getMenu().getLoginMenu())
                self.setOption(int(input("Enter your option: ")))
                if self.getOption() == 0:
                    print()
                    break;
                elif self.getOption() == 1:
                    self.setOption(self.register())
                    if self.getOption() == 0:
                        self.setOption(None)
                        continue
                elif self.getOption() == 2:
                    self.setOption(self.logIn())
                    if self.getOption() == 0:
                        self.setOption(None)
                        continue
                    elif self.getOption() != 0:
                        self.getMenuRequirementOption()
                        if self.getOption() == 0:
                            self.setOption(None)
                            continue
                        self.getTabRequirementOption()
                        if self.getOption() == 0:
                            self.setOption(None)
                            continue
                        self.getToolbarRequirementOption()
                        if self.getOption() == 0:
                            self.setOption(None)
                            continue
                        db = Database()
                        ties = db.checkForTies()
                        tieCount = 0
                        #tabs
                        if ties[0] == 1:
                            coin = Coin()
                            coin.flip()
                            winCount = 0
                            loseCount = 0
                            tieCount += 1
                            #win
                            if coin.result == 'heads':
                                print()
                                print("There was one conflict regarding tab orientation and you WON the coin toss!")
                                winCount += 1
                            #lose
                            elif coin.result == 'tails':
                                print()
                                print("There was one conflict regarding tab orientation and you LOST the coin toss!")
                                print("Updating project specifications.")
                                loseCount += 1
                                if(self.getSoftware().getVTabs() == True):
                                    self.getSoftware().setVTabs(False)
                                    self.getSoftware().setHTabs(True)
                                elif(self.getSoftware().getHTabs() == True):
                                    self.getSoftware().setVTabs(True)
                                    self.getSoftware().setHTabs(False)
                        if ties[5] == 1:
                            coin = Coin()
                            coin.flip()
                            winCount = 0
                            loseCount = 0
                            tieCount += 1
                            #win
                            if coin.result == 'heads':
                                print()
                                print("There was one conflict regarding the toolbar and you WON the coin toss!")
                                winCount += 1
                            #lose
                            elif coin.result == 'tails':
                                print()
                                print("There was one conflict regarding the toolbar and you LOST the coin toss!")
                                print("Updating project specifications.")
                                loseCount += 1
                                if(self.getSoftware().getToolbar()):
                                    self.getSoftware().setToolbar(False)
                                elif(not self.getSoftware().getToolbar()):
                                    self.getSoftware().setToolbar(True)
                        #3 way tie
                        if ties[4] == 1:
                            die = Dice()
                            die.roll()
                            tieBreaker = die.result
                            tieCount += 1
                            # four menu items
                            if tieBreaker == 1:
                                print()
                                print("There was a three-way tie between the number of menu items.")
                                print("You roll a three-side die and return a '1', indicating there will be four menu items.")
                                print("Updating specifications as needed.")
                                self.getSoftware().setMenuFile(True)
                                self.getSoftware().setMenuRepo(True)
                                self.getSoftware().setMenuComm(True)
                                self.getSoftware().setMenuTools(False)
                                self.getSoftware().setMenuView(False)
                                self.getSoftware().setMenuNav(False)
                                self.getSoftware().setMenuPlug(False)
                                self.getSoftware().setMenuHelp(True)
                                self.getSoftware().setMenuItemCount(4)
                            # six menu items
                            if tieBreaker == 2:
                                print()
                                print("There was a three-way tie between the number of menu items.")
                                print("You roll a three-sided die and return a '2', indicating that there will be six menu items.")
                                print("Updating specifications as needed.")
                                self.getSoftware().setMenuFile(True)
                                self.getSoftware().setMenuRepo(True)
                                self.getSoftware().setMenuComm(True)
                                self.getSoftware().setMenuTools(True)
                                self.getSoftware().setMenuView(False)
                                self.getSoftware().setMenuNav(False)
                                self.getSoftware().setMenuPlug(True)
                                self.getSoftware().setMenuHelp(True)
                                self.getSoftware().setMenuItemCount(6)
                            # eight menu items
                            if tieBreaker == 3:
                                print()
                                print("There was a three-way tie between the number of menu items.")
                                print("You roll a three-sided die and return a '3', indicating that there will be eight menu items.")
                                print("Updating specifications as needed.")
                                self.getSoftware().setMenuFile(True)
                                self.getSoftware().setMenuRepo(True)
                                self.getSoftware().setMenuComm(True)
                                self.getSoftware().setMenuTools(True)
                                self.getSoftware().setMenuView(True)
                                self.getSoftware().setMenuNav(True)
                                self.getSoftware().setMenuPlug(True)
                                self.getSoftware().setMenuHelp(True)
                                self.getSoftware().setMenuItemCount(8)
                        #four six tie
                        elif ties[1] == 1:
                            coin = Coin()
                            coin.flip()
                            winCount = 0
                            loseCount = 0
                            tieCount += 1
                            #win
                            if coin.result == 'heads':
                                print()
                                print("There was a conflict between four and six menu items and you WON the coin toss!")
                                winCount += 1
                            #lose
                            elif coin.result == 'tails':
                                print()
                                print("There was a conflict between four and six menu items and you LOST the coin toss!")
                                print("Updating project specifications.")
                                loseCount += 1
                                if(self.getSoftware().getMenuItemCount() == 4):
                                    self.getSoftware().setMenuFile(True)
                                    self.getSoftware().setMenuRepo(True)
                                    self.getSoftware().setMenuComm(True)
                                    self.getSoftware().setMenuTools(True)
                                    self.getSoftware().setMenuView(False)
                                    self.getSoftware().setMenuNav(False)
                                    self.getSoftware().setMenuPlug(True)
                                    self.getSoftware().setMenuHelp(True)
                                    self.getSoftware().setMenuItemCount(6)
                                elif(self.getSoftware().getMenuItemCount() == 6):
                                    self.getSoftware().setMenuFile(True)
                                    self.getSoftware().setMenuRepo(True)
                                    self.getSoftware().setMenuComm(True)
                                    self.getSoftware().setMenuTools(False)
                                    self.getSoftware().setMenuView(False)
                                    self.getSoftware().setMenuNav(False)
                                    self.getSoftware().setMenuPlug(False)
                                    self.getSoftware().setMenuHelp(True)
                                    self.getSoftware().setMenuItemCount(4)
                        # 4 8 tie
                        elif ties[2] == 1:
                            coin = Coin()
                            coin.flip()
                            winCount = 0
                            loseCount = 0
                            tieCount += 1
                            #win
                            if coin.result == 'heads':
                                print()
                                print("There was one conflict between four and eight menu items and you WON the coin toss!")
                                winCount += 1
                            #lose
                            elif coin.result == 'tails':
                                print()
                                print("There was one conflict between four and eight menu items and you LOST the coin toss!")
                                print("Updating project specifications.")
                                loseCount += 1
                                if(self.getSoftware().getMenuItemCount() == 4):
                                    self.getSoftware().setMenuFile(True)
                                    self.getSoftware().setMenuRepo(True)
                                    self.getSoftware().setMenuComm(True)
                                    self.getSoftware().setMenuTools(True)
                                    self.getSoftware().setMenuView(True)
                                    self.getSoftware().setMenuNav(True)
                                    self.getSoftware().setMenuPlug(True)
                                    self.getSoftware().setMenuHelp(True)
                                    self.getSoftware().setMenuItemCount(8)
                                elif(self.getSoftware().getMenuItemCount() == 8):
                                    self.getSoftware().setMenuFile(True)
                                    self.getSoftware().setMenuRepo(True)
                                    self.getSoftware().setMenuComm(True)
                                    self.getSoftware().setMenuTools(False)
                                    self.getSoftware().setMenuView(False)
                                    self.getSoftware().setMenuNav(False)
                                    self.getSoftware().setMenuPlug(False)
                                    self.getSoftware().setMenuHelp(True)
                                    self.getSoftware().setMenuItemCount(4)
                        # 6 8 tie
                        elif ties[3] == 1:
                            coin = Coin()
                            coin.flip()
                            winCount = 0
                            loseCount = 0
                            tieCount += 1
                            #win
                            if coin.result == 'heads':
                                print()
                                print("There was a conflict between six and eight menu items and you WON the coin toss!")
                                winCount += 1
                            #lose
                            elif coin.result == 'tails':
                                print()
                                print("There was a conflict between six and eight menu items and you LOST the coin toss!")
                                print("Updating project specifications.")
                                loseCount += 1
                                if(self.getSoftware().getMenuItemCount() == 6):
                                    self.getSoftware().setMenuFile(True)
                                    self.getSoftware().setMenuRepo(True)
                                    self.getSoftware().setMenuComm(True)
                                    self.getSoftware().setMenuTools(True)
                                    self.getSoftware().setMenuView(True)
                                    self.getSoftware().setMenuNav(True)
                                    self.getSoftware().setMenuPlug(True)
                                    self.getSoftware().setMenuHelp(True)
                                    self.getSoftware().setMenuItemCount(8)
                                elif(self.getSoftware().getMenuItemCount() == 8):
                                    self.getSoftware().setMenuFile(True)
                                    self.getSoftware().setMenuRepo(True)
                                    self.getSoftware().setMenuComm(True)
                                    self.getSoftware().setMenuTools(True)
                                    self.getSoftware().setMenuView(False)
                                    self.getSoftware().setMenuNav(False)
                                    self.getSoftware().setMenuPlug(True)
                                    self.getSoftware().setMenuHelp(True)
                                    self.getSoftware().setMenuItemCount(6)
                        self.getFile().createDirectory(self.getEmail())
                        self.getFile().createPlantUMLSource(self.getSoftware())
                        self.getFile().createImage()
                        print(self.getMenu().getCreatingImageMessage())
                        self.getFile().showImage()
                else:
                    print()
                    print("Invalid option.")
            #if user does not input a number, this error is thrown      
            except ValueError:
                print()
                print("Input must be a number.")
        print("Thanks for using this program! Goodbye!")
        
    def getMenuRequirementOption(self):
        while self.getOption() != 0:
            try:
                print(self.getMenu().getMenuRequirementMenu())
                self.setOption(int(input("Enter your option: ")))
                if self.getOption() == 0:
                    return 0
                if self.getOption() == 1:
                    #todo check for ties
                    db = Database()
                    self.getSoftware().setMenuFile(True)
                    self.getSoftware().setMenuRepo(True)
                    self.getSoftware().setMenuComm(True)
                    self.getSoftware().setMenuTools(False)
                    self.getSoftware().setMenuView(False)
                    self.getSoftware().setMenuNav(False)
                    self.getSoftware().setMenuPlug(False)
                    self.getSoftware().setMenuHelp(True)
                    self.getSoftware().setMenuItemCount(4)
                    return 1
                elif self.getOption() == 2:
                    self.getSoftware().setMenuFile(True)
                    self.getSoftware().setMenuRepo(True)
                    self.getSoftware().setMenuComm(True)
                    self.getSoftware().setMenuTools(True)
                    self.getSoftware().setMenuView(False)
                    self.getSoftware().setMenuNav(False)
                    self.getSoftware().setMenuPlug(True)
                    self.getSoftware().setMenuHelp(True)
                    self.getSoftware().setMenuItemCount(6)
                    return 2
                elif self.getOption() == 3:
                    self.getSoftware().setMenuFile(True)
                    self.getSoftware().setMenuRepo(True)
                    self.getSoftware().setMenuComm(True)
                    self.getSoftware().setMenuTools(True)
                    self.getSoftware().setMenuView(True)
                    self.getSoftware().setMenuNav(True)
                    self.getSoftware().setMenuPlug(True)
                    self.getSoftware().setMenuHelp(True)
                    self.getSoftware().setMenuItemCount(8)
                    return 3
                else:
                    print()
                    print("Invalid option.")
            #if user does not input a number, this error is thrown      
            except ValueError:
                print()
                print("Input must be a number.")
        return 0
                
    def getTabRequirementOption(self):
        while self.getOption() != 0:
            try:
                print(self.getMenu().getTabRequirementMenu())
                self.setOption(int(input("Enter your option: ")))
                if self.getOption() == 0:
                    return 0
                elif self.getOption() == 1:
                    self.getSoftware().setVTabs(True)
                    self.getSoftware().setHTabs(False)
                    return 1
                elif self.getOption() == 2:
                    self.getSoftware().setVTabs(False)
                    self.getSoftware().setHTabs(True)
                    return 2
                else:
                    print()
                    print("Invalid option.")
            #if user does not input a number, this error is thrown      
            except ValueError:
                print()
                print("Input must be a number.")

    def getToolbarRequirementOption(self):
        while self.getOption() != 0:
            try:
                print(self.getMenu().getToolbarRequirementMenu())
                self.setOption(int(input("Enter your option: ")))
                if self.getOption() == 0:
                    return 0
                elif self.getOption() == 1:
                    self.getSoftware().setToolbar(True)
                    db = Database()
                    db.insertSpecification(self.getEmail(), self.getSoftware())
                    return 1
                elif self.getOption() == 2:
                    self.getSoftware().setToolbar(False)
                    db = Database()
                    db.insertSpecification(self.getEmail(), self.getSoftware())
                    return 2
                else:
                    print()
                    print("Invalid option.")
            #if user does not input a number, this error is thrown      
            except ValueError:
                print()
                print("Input must be a number.")

    def register(self):
        print()
        print("**********************************")
        print("*     Registering a new user     *")
        print("**********************************")
        #database object to check if user is available
        db = Database()
        print()
        self.setEmail(input("Enter your email (0 to exit): "))
        if self.getEmail() == '0':
            return 0
        while not (self.validEmail(self.getEmail())):
            print()
            print("Email must be valid.")
            print()
            self.setEmail(input("Enter your email (0 to exit): "))
            if self.getEmail() == '0':
                return 0
        if db.userAvailable(self.getEmail()):
            print()
            print("Username is available.")
            self.setPin(self.getUserPin())
            if self.getPin() == 0:
                return 0
            print()
            db.insertUserAndPin(self.getEmail(), self.getPin())
            print("**************************")
            print("*     New User Added     *")
            print("**************************")
        else:
            print()
            print("User already exists.")
            print("Please choose a new username or log in.")
    
    def validEmail(self, email):
        regex = '^[A-Za-z0-9]+[\._]?[A-Za-z0-9]+[@]\w+[.]\w{2,3}$'
        if re.search(regex,email):
            return True
        else:
            return False
    
    def getUserPin(self):
            while (True):
                print()
                self.setPinString(input("Enter your 4-digit pin number (0 to exit): "))
                try:
                    self.setPin(int(self.getPinString()))
                    if (self.getPin() == 0):
                        break;
                    if len(self.getPinString()) < 4 or len(self.getPinString()) > 4:
                        print()
                        print("Pin must contain four digits.")
                    elif len(self.getPinString()) == 4:
                        break;
                except ValueError:
                    print()
                    print("Pin numbers can only contain digits.")
            return self.getPin()
    
    def logIn(self):
        print()
        print("*************************")
        print("*     Log in Screen     *")
        print("*************************")
        print()
        self.setEmail(None)
        self.setEmail(input("Enter your email (0 to exit): "))
        if (self.getEmail() == '0'):
            return 0
        while not (self.validEmail(self.getEmail())):
            print()
            print("Email must be valid.")
            print()
            self.setEmail(input("Enter your email (0 to exit): "))
            if (self.getEmail() == '0'):
                return 0
        self.setPin(self.getUserPin())
        if (self.getPin() == 0):
            return 0
        db = Database()
        while not (db.validPin(self.getEmail(), self.getPin())):
            print()
            print("Pin does not match pin on file.")
            print("Please try again.")
            self.setPin(self.getUserPin())
            if (self.getPin() == 0):
                return 0
        return